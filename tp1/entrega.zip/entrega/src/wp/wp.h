#ifndef __wq_H_INCLUDED__   //   #define this so the compiler knows it has been included
#define __wq_H_INCLUDED__   //   #define this so the compiler knows it has been included

#include "../instancia/instancia.h"
#include <iostream>
using namespace std;

double* wp(instancia*);

#endif
