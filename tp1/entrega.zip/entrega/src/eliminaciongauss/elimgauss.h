#ifndef __Gauss_H_INCLUDED__   
#define __Gauss_H_INCLUDED__   

#include "../matriz/matriz.h"
#include <iostream>
using namespace std;

double* gauss(Matriz*,double *b);

#endif
